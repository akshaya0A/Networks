#!/bin/sh
dname=$(dirname ${BASH_SOURCE[0]})
python3 $dname/lab1-client.py $1 $2